from __future__ import annotations

import argparse
import json
import urllib.request
from pathlib import Path
from typing import Any

SPLITS = ["train", "valid_freq", "valid_rare", "test_freq", "test_rare"]

WIKI_URL = "https://raw.githubusercontent.com/alexa/Topical-Chat/master/src/wiki/wiki.json"


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def save_jsonl(records: list[dict[str, Any]], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for record in records:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")


def short_text(text: Any, limit: int = 300) -> str:
    if text is None:
        return "None"
    if not isinstance(text, str):
        text = json.dumps(text, ensure_ascii=False)
    text = text.replace("\n", " ").strip()
    return text if len(text) <= limit else text[:limit] + " ..."


def download_wiki_if_missing(wiki_path: Path) -> bool:
    if wiki_path.exists():
        return False

    wiki_path.parent.mkdir(parents=True, exist_ok=True)

    req = urllib.request.Request(
        WIKI_URL,
        headers={"User-Agent": "Mozilla/5.0"}
    )

    with urllib.request.urlopen(req, timeout=120) as response:
        data = response.read()

    wiki_path.write_bytes(data)
    return True


def invert_text_to_id_map(text_to_id: dict[str, Any]) -> dict[int, str]:
    out: dict[int, str] = {}
    for text, idx in text_to_id.items():
        out[int(idx)] = text
    return out


def resolve_fs_doc(
    fs_obj: dict[str, Any],
    short_inv: dict[int, str],
    summ_inv: dict[int, str],
) -> dict[str, Any] | None:
    entity = fs_obj.get("entity")

    if "shortened_wiki_lead_section" in fs_obj:
        wiki_id = int(fs_obj["shortened_wiki_lead_section"])
        text = short_inv.get(wiki_id)
        style = "shortened"
    elif "summarized_wiki_lead_section" in fs_obj:
        wiki_id = int(fs_obj["summarized_wiki_lead_section"])
        text = summ_inv.get(wiki_id)
        style = "summarized"
    else:
        return None

    if not text:
        return None

    return {
        "doc_id": f"wiki::{style}::{wiki_id}",
        "wiki_id": wiki_id,
        "style": style,
        "entity": entity,
        "text": text,
        "source": "wiki",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True, help="Path to your NLP Project folder")
    args = parser.parse_args()

    repo = Path(args.repo).expanduser().resolve()

    wiki_path = repo / "assets" / "wiki" / "wiki.json"
    outputs_dir = repo / "outputs"

    downloaded = download_wiki_if_missing(wiki_path)

    wiki_data = load_json(wiki_path)
    short_inv = invert_text_to_id_map(wiki_data.get("shortened_wiki_lead_section", {}))
    summ_inv = invert_text_to_id_map(wiki_data.get("summarized_wiki_lead_section", {}))

    docs_by_id: dict[str, dict[str, Any]] = {}
    grounded_turns: list[dict[str, Any]] = []

    split_stats: dict[str, dict[str, int]] = {}

    for split in SPLITS:
        conv_path = repo / "conversations" / f"{split}.json"
        prebuild_path = repo / "reading_sets" / "pre-build" / f"{split}.json"

        if not conv_path.exists() or not prebuild_path.exists():
            print(f"Skipping split {split}: missing file(s)")
            continue

        conv_data = load_json(conv_path)
        prebuild_data = load_json(prebuild_path)

        split_stats[split] = {
            "conversations": len(conv_data),
            "prebuild_entries": len(prebuild_data),
            "grounded_turns_with_fs": 0,
            "resolved_fs_links": 0,
        }

        for conv_id, conv in conv_data.items():
            if conv_id not in prebuild_data:
                continue

            pre = prebuild_data[conv_id]

            fs_map_for_conv: dict[str, dict[str, str]] = {
                "agent_1": {},
                "agent_2": {},
            }

            for agent in ["agent_1", "agent_2"]:
                agent_obj = pre.get(agent, {})
                if not isinstance(agent_obj, dict):
                    continue

                for label, fs_obj in agent_obj.items():
                    if not label.startswith("FS"):
                        continue
                    if not isinstance(fs_obj, dict):
                        continue

                    resolved = resolve_fs_doc(fs_obj, short_inv, summ_inv)
                    if resolved is None:
                        continue

                    doc_id = resolved["doc_id"]

                    if doc_id not in docs_by_id:
                        docs_by_id[doc_id] = {
                            "doc_id": doc_id,
                            "wiki_id": resolved["wiki_id"],
                            "style": resolved["style"],
                            "entity": resolved["entity"],
                            "text": resolved["text"],
                            "source": "wiki",
                            "splits": set(),
                        }

                    docs_by_id[doc_id]["splits"].add(split)
                    fs_map_for_conv[agent][label] = doc_id
                    split_stats[split]["resolved_fs_links"] += 1

            for turn_idx, turn in enumerate(conv.get("content", [])):
                knowledge_sources = turn.get("knowledge_source", [])
                if not isinstance(knowledge_sources, list):
                    knowledge_sources = []

                fs_labels = [x for x in knowledge_sources if isinstance(x, str) and x.startswith("FS")]
                if not fs_labels:
                    continue

                agent = turn.get("agent")
                agent_fs_map = fs_map_for_conv.get(agent, {})

                gold_doc_ids = []
                for fs_label in fs_labels:
                    doc_id = agent_fs_map.get(fs_label)
                    if doc_id:
                        gold_doc_ids.append(doc_id)

                grounded_turns.append({
                    "split": split,
                    "conv_id": conv_id,
                    "turn_index": turn_idx,
                    "agent": agent,
                    "message": turn.get("message"),
                    "knowledge_source_labels": knowledge_sources,
                    "gold_doc_ids": gold_doc_ids,
                    "uses_personal_knowledge": "Personal Knowledge" in knowledge_sources,
                    "article_url": conv.get("article_url"),
                    "config": conv.get("config"),
                })

                split_stats[split]["grounded_turns_with_fs"] += 1

    wiki_docs = []
    for doc in docs_by_id.values():
        wiki_docs.append({
            "doc_id": doc["doc_id"],
            "wiki_id": doc["wiki_id"],
            "style": doc["style"],
            "entity": doc["entity"],
            "text": doc["text"],
            "source": doc["source"],
            "splits": sorted(doc["splits"]),
        })

    wiki_docs = sorted(wiki_docs, key=lambda x: x["doc_id"])
    grounded_turns = sorted(
        grounded_turns,
        key=lambda x: (x["split"], x["conv_id"], x["turn_index"])
    )

    wiki_docs_path = outputs_dir / "wiki_docs.jsonl"
    grounded_turns_path = outputs_dir / "fs_grounded_turns.jsonl"
    stats_path = outputs_dir / "checkpoint_02_stats.json"

    save_jsonl(wiki_docs, wiki_docs_path)
    save_jsonl(grounded_turns, grounded_turns_path)

    stats_output = {
        "downloaded_wiki_json": downloaded,
        "wiki_json_path": str(wiki_path),
        "num_shortened_wiki_entries": len(short_inv),
        "num_summarized_wiki_entries": len(summ_inv),
        "num_unique_wiki_docs": len(wiki_docs),
        "num_grounded_turns_with_fs": len(grounded_turns),
        "split_stats": split_stats,
    }

    stats_path.parent.mkdir(parents=True, exist_ok=True)
    with stats_path.open("w", encoding="utf-8") as f:
        json.dump(stats_output, f, indent=2, ensure_ascii=False)

    print("\n" + "=" * 100)
    print("CHECKPOINT 2 RESULTS")
    print("=" * 100)
    print(f"wiki.json downloaded now? : {downloaded}")
    print(f"wiki.json path            : {wiki_path}")
    print(f"shortened wiki entries    : {len(short_inv)}")
    print(f"summarized wiki entries   : {len(summ_inv)}")
    print(f"unique wiki docs          : {len(wiki_docs)}")
    print(f"FS-grounded turns         : {len(grounded_turns)}")
    print(f"saved wiki docs           : {wiki_docs_path}")
    print(f"saved grounded turns      : {grounded_turns_path}")
    print(f"saved stats               : {stats_path}")

    print("\nPer-split summary:")
    for split, stat in split_stats.items():
        print(
            f"  {split:10s} | conversations={stat['conversations']:5d} "
            f"| prebuild={stat['prebuild_entries']:5d} "
            f"| grounded_turns_with_fs={stat['grounded_turns_with_fs']:6d} "
            f"| resolved_fs_links={stat['resolved_fs_links']:6d}"
        )

    if wiki_docs:
        print("\nSample wiki doc:")
        print(json.dumps(wiki_docs[0], indent=2, ensure_ascii=False)[:1500])

    if grounded_turns:
        print("\nSample grounded turn:")
        print(json.dumps(grounded_turns[0], indent=2, ensure_ascii=False)[:1500])

    print("\nDONE. Paste the terminal output here.")


if __name__ == "__main__":
    main()