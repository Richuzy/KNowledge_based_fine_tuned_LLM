from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import chromadb
from sentence_transformers import SentenceTransformer


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    return records


def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)


def get_or_create_collection(client, name: str):
    try:
        return client.get_or_create_collection(
            name=name,
            configuration={"hnsw": {"space": "cosine"}},
        )
    except TypeError:
        return client.get_or_create_collection(
            name=name,
            metadata={"hnsw:space": "cosine"},
        )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True, help="Path to your NLP Project folder")
    parser.add_argument("--collection_name", default="topical_chat_wiki")
    parser.add_argument("--embed_model", default="sentence-transformers/all-MiniLM-L6-v2")
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--rebuild", action="store_true")
    parser.add_argument("--embed_device", default="cpu", help="cpu or cuda")
    args = parser.parse_args()

    repo = Path(args.repo).expanduser().resolve()
    wiki_docs_path = repo / "outputs" / "wiki_docs.jsonl"
    chroma_dir = repo / "vectorstores" / "chroma_wiki"

    if not wiki_docs_path.exists():
        raise FileNotFoundError(f"Missing file: {wiki_docs_path}")

    wiki_docs = load_jsonl(wiki_docs_path)
    print(f"Loaded wiki docs: {len(wiki_docs)}")

    chroma_dir.mkdir(parents=True, exist_ok=True)
    client = chromadb.PersistentClient(path=str(chroma_dir))

    if args.rebuild:
        try:
            client.delete_collection(args.collection_name)
            print(f"Deleted old collection: {args.collection_name}")
        except Exception:
            pass

    collection = get_or_create_collection(client, args.collection_name)

    existing_count = collection.count()
    if existing_count > 0 and not args.rebuild:
        print(f"Collection already exists with {existing_count} rows. Use --rebuild to recreate.")
        stats = {
            "collection_name": args.collection_name,
            "persist_dir": str(chroma_dir),
            "embed_model": args.embed_model,
            "existing_count": existing_count,
            "reused_existing_collection": True,
        }
        save_json(repo / "outputs" / "checkpoint_06_chroma_stats.json", stats)
        return

    encoder = SentenceTransformer(args.embed_model, device=args.embed_device)

    ids = []
    docs = []
    metas = []

    for doc in wiki_docs:
        doc_id = doc["doc_id"]
        entity = doc.get("entity", "")
        text = doc.get("text", "")

        ids.append(doc_id)
        docs.append(f"Entity: {entity}\nText: {text}")
        metas.append({
            "doc_id": doc_id,
            "entity": entity,
            "wiki_id": int(doc.get("wiki_id", -1)),
            "style": doc.get("style", ""),
            "source": doc.get("source", "wiki"),
        })

    total = len(docs)
    print(f"Building embeddings for {total} documents using {args.embed_model} on {args.embed_device}...")

    for start in range(0, total, args.batch_size):
        end = min(start + args.batch_size, total)
        batch_docs = docs[start:end]
        batch_ids = ids[start:end]
        batch_metas = metas[start:end]

        batch_emb = encoder.encode(
            batch_docs,
            batch_size=args.batch_size,
            show_progress_bar=False,
            normalize_embeddings=True,
        )

        collection.add(
            ids=batch_ids,
            documents=batch_docs,
            metadatas=batch_metas,
            embeddings=batch_emb.tolist(),
        )

        print(f"Indexed {end}/{total}")

    print(f"Final collection count: {collection.count()}")

    sample = collection.query(
        query_embeddings=encoder.encode(
            ["What is football?"],
            normalize_embeddings=True,
        ).tolist(),
        n_results=3,
        include=["documents", "metadatas", "distances"],
    )

    stats = {
        "collection_name": args.collection_name,
        "persist_dir": str(chroma_dir),
        "embed_model": args.embed_model,
        "embed_device": args.embed_device,
        "num_docs": total,
        "final_collection_count": collection.count(),
        "sample_query": "What is football?",
        "sample_result_doc_ids": sample.get("ids", [[]])[0],
        "sample_result_distances": sample.get("distances", [[]])[0],
    }
    save_json(repo / "outputs" / "checkpoint_06_chroma_stats.json", stats)

    print("\nDone.")
    print(f"Saved stats to: {repo / 'outputs' / 'checkpoint_06_chroma_stats.json'}")
    print(f"Chroma DB path: {chroma_dir}")


if __name__ == "__main__":
    main()