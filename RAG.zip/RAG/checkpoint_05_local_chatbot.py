from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
from typing import Any

import torch

from checkpoint_04_rag_generate import (
    load_jsonl,
    BM25Retriever,
    load_model_and_tokenizer,
)


def short_text(text: Any, limit: int = 220) -> str:
    if text is None:
        return "None"
    if not isinstance(text, str):
        text = json.dumps(text, ensure_ascii=False)
    text = text.replace("\n", " ").strip()
    return text if len(text) <= limit else text[:limit] + " ..."


def history_to_text(chat_history: list[dict[str, str]], max_turns: int = 4) -> str:
    recent = chat_history[-max_turns:]
    lines = []
    for turn in recent:
        role = turn["role"].capitalize()
        lines.append(f"{role}: {turn['content']}")
    return "\n".join(lines)


def append_jsonl(path: Path, record: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


def build_messages(query: str, history: str, retrieved_docs: list[dict[str, Any]]) -> list[dict[str, str]]:
    evidence_blocks = []
    for i, doc in enumerate(retrieved_docs, start=1):
        evidence_blocks.append(
            f"[{i}] Entity: {doc.get('entity')}\n"
            f"Document ID: {doc.get('doc_id')}\n"
            f"Text: {doc.get('text')}"
        )

    evidence_text = "\n\n".join(evidence_blocks) if evidence_blocks else "(no evidence retrieved)"
    history_text = history.strip() if history.strip() else "(none)"

    system_prompt = (
        "You are a knowledge-grounded explainer chatbot. "
        "Use only the retrieved evidence. "
        "Do not invent facts. "
        "Do not claim personal opinions, feelings, or preferences. "
        "If the user asks what you like, prefer, enjoy, or believe, say that you do not have personal preferences "
        "and then answer factually from the evidence. "
        "If the evidence is insufficient, say that you do not have enough grounded evidence. "
        "Keep answers short, clear, and factual."
    )

    user_prompt = (
        f"Conversation history:\n{history_text}\n\n"
        f"Retrieved evidence:\n{evidence_text}\n\n"
        f"User question:\n{query}\n\n"
        f"Requirements:\n"
        f"- Answer in 2 to 5 sentences.\n"
        f"- Use only the retrieved evidence.\n"
        f"- Do not act like you have personal experience.\n"
        f"- End with a final line exactly like this: Sources: [1], [2]\n"
        f"  Use only the source numbers that were actually useful.\n"
    )

    return [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]


def format_prompt(tokenizer, messages: list[dict[str, str]]) -> str:
    if hasattr(tokenizer, "apply_chat_template"):
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
        )

    parts = []
    for msg in messages:
        parts.append(f"{msg['role'].upper()}:\n{msg['content']}\n")
    parts.append("ASSISTANT:\n")
    return "\n".join(parts)


def generate_answer(tokenizer, model, messages: list[dict[str, str]], max_new_tokens: int = 100) -> str:
    prompt = format_prompt(tokenizer, messages)
    batch = tokenizer(prompt, return_tensors="pt")

    model_device = next(model.parameters()).device
    batch = {k: v.to(model_device) for k, v in batch.items()}

    gen_cfg = copy.deepcopy(model.generation_config)
    gen_cfg.do_sample = False

    for attr in ("temperature", "top_p", "top_k"):
        if hasattr(gen_cfg, attr):
            try:
                setattr(gen_cfg, attr, None)
            except Exception:
                pass

    with torch.no_grad():
        output = model.generate(
            **batch,
            generation_config=gen_cfg,
            max_new_tokens=max_new_tokens,
            repetition_penalty=1.05,
            use_cache=True,
            pad_token_id=tokenizer.eos_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )

    new_tokens = output[0][batch["input_ids"].shape[1]:]
    answer = tokenizer.decode(new_tokens, skip_special_tokens=True).strip()
    return answer


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True, help="Path to your NLP Project folder")
    parser.add_argument("--model_id", required=True, help="Hugging Face model id")
    parser.add_argument("--top_k", type=int, default=2)
    parser.add_argument("--max_new_tokens", type=int, default=90)
    parser.add_argument("--max_history_turns", type=int, default=4)
    args = parser.parse_args()

    repo = Path(args.repo).expanduser().resolve()
    wiki_docs_path = repo / "outputs" / "wiki_docs.jsonl"

    if not wiki_docs_path.exists():
        raise FileNotFoundError(f"Missing file: {wiki_docs_path}")

    print("\nLoading wiki docs...")
    wiki_docs = load_jsonl(wiki_docs_path)
    retriever = BM25Retriever(wiki_docs)
    print(f"Indexed docs: {len(wiki_docs)}")

    print("\nLoading model once...")
    tokenizer, model = load_model_and_tokenizer(args.model_id)
    print("Model loaded successfully.")

    print("\n" + "=" * 90)
    print("LOCAL RAG CHATBOT")
    print(f"Model: {args.model_id}")
    print("Type your question and press Enter.")
    print("Type 'exit' or 'quit' to stop.")
    print("=" * 90)

    chat_history: list[dict[str, str]] = []
    session_path = repo / "outputs" / "checkpoint_05_chat_session.jsonl"

    while True:
        query = input("\nYou: ").strip()

        if not query:
            continue
        if query.lower() in {"exit", "quit"}:
            print("Exiting chat.")
            break

        history_text = history_to_text(chat_history, max_turns=args.max_history_turns)
        retrieval_query = f"{history_text} {query}".strip()

        top_docs = retriever.search(retrieval_query, top_k=args.top_k)

        print("\nRetrieved docs:")
        if not top_docs:
            print("  No evidence retrieved.")
            answer = "I do not have enough grounded evidence to answer that confidently."
        else:
            for i, doc in enumerate(top_docs, start=1):
                print(f"  [{i}] {doc['doc_id']} | entity={doc['entity']} | score={doc['score']:.4f}")
                print(f"      {short_text(doc['text'], 160)}")

            messages = build_messages(query, history_text, top_docs)
            answer = generate_answer(
                tokenizer=tokenizer,
                model=model,
                messages=messages,
                max_new_tokens=args.max_new_tokens,
            )

        print(f"\nBot: {answer}")

        chat_history.append({"role": "user", "content": query})
        chat_history.append({"role": "assistant", "content": answer})

        append_jsonl(session_path, {
            "model_id": args.model_id,
            "query": query,
            "history_used": history_text,
            "retrieved_docs": top_docs,
            "answer": answer,
        })

    print(f"\nChat session saved to:\n{session_path}")


if __name__ == "__main__":
    main()