from __future__ import annotations

import argparse
import copy
import csv
import json
import random
import re
from pathlib import Path
from typing import Any

import torch

from checkpoint_04_rag_generate import load_jsonl, BM25Retriever, load_model_and_tokenizer


TOKEN_PATTERN = re.compile(r"[a-z0-9]+")


def tokenize(text: str) -> list[str]:
    if not text:
        return []
    return TOKEN_PATTERN.findall(text.lower())


def short_text(text: Any, limit: int = 220) -> str:
    if text is None:
        return "None"
    if not isinstance(text, str):
        text = json.dumps(text, ensure_ascii=False)
    text = text.replace("\n", " ").strip()
    return text if len(text) <= limit else text[:limit] + " ..."


def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)


def save_jsonl(path: Path, records: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for record in records:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")


def has_prefix(labels: list[str], prefix: str) -> bool:
    return any(isinstance(x, str) and x.startswith(prefix) for x in labels)


def load_conversations(repo: Path) -> dict[str, dict[str, Any]]:
    all_convs: dict[str, dict[str, Any]] = {}
    for split in ["train", "valid_freq", "valid_rare", "test_freq", "test_rare"]:
        path = repo / "conversations" / f"{split}.json"
        if not path.exists():
            continue
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        for conv_id, conv in data.items():
            all_convs[f"{split}::{conv_id}"] = conv
    return all_convs


def build_history_text(conv: dict[str, Any], turn_index: int, max_prev_turns: int = 2) -> str:
    turns = conv.get("content", [])
    start = max(0, turn_index - max_prev_turns)
    history_turns = turns[start:turn_index]

    lines = []
    for t in history_turns:
        speaker = "User" if t.get("agent") == "agent_1" else "Assistant"
        lines.append(f"{speaker}: {t.get('message', '')}")
    return "\n".join(lines)


def build_messages(query: str, history: str, retrieved_docs: list[dict[str, Any]]) -> list[dict[str, str]]:
    evidence_blocks = []
    for i, doc in enumerate(retrieved_docs, start=1):
        evidence_blocks.append(
            f"[{i}] Entity: {doc.get('entity')}\n"
            f"Document ID: {doc.get('doc_id')}\n"
            f"Text: {doc.get('text')}"
        )

    evidence_text = "\n\n".join(evidence_blocks) if evidence_blocks else "(no evidence)"
    history_text = history.strip() if history.strip() else "(none)"

    system_prompt = (
        "You are a knowledge-grounded explainer chatbot. "
        "Use only the retrieved evidence. "
        "Do not invent facts. "
        "Do not claim personal opinions, preferences, habits, or experiences. "
        "If the user asks what you like, enjoy, think, or watch, say that you do not have personal opinions or experiences, "
        "then answer factually only from the evidence if possible. "
        "If the evidence is weak or insufficient, say that you do not have enough grounded evidence."
    )

    user_prompt = (
        f"Conversation history:\n{history_text}\n\n"
        f"Retrieved evidence:\n{evidence_text}\n\n"
        f"User question:\n{query}\n\n"
        f"Requirements:\n"
        f"- Answer in 2 to 4 sentences.\n"
        f"- Use only the evidence above.\n"
        f"- Never pretend to have personal preferences.\n"
        f"- End with: Sources: [1], [2]\n"
        f"  Only include source numbers that were actually useful.\n"
    )

    return [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]


def format_prompt(tokenizer, messages: list[dict[str, str]]) -> str:
    if hasattr(tokenizer, "apply_chat_template"):
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
        )

    parts = []
    for msg in messages:
        parts.append(f"{msg['role'].upper()}:\n{msg['content']}\n")
    parts.append("ASSISTANT:\n")
    return "\n".join(parts)


def generate_answer(tokenizer, model, messages: list[dict[str, str]], max_new_tokens: int = 90) -> str:
    prompt = format_prompt(tokenizer, messages)
    batch = tokenizer(prompt, return_tensors="pt")
    model_device = next(model.parameters()).device
    batch = {k: v.to(model_device) for k, v in batch.items()}

    gen_cfg = copy.deepcopy(model.generation_config)
    gen_cfg.do_sample = False

    for attr in ("temperature", "top_p", "top_k"):
        if hasattr(gen_cfg, attr):
            try:
                setattr(gen_cfg, attr, None)
            except Exception:
                pass

    with torch.no_grad():
        output = model.generate(
            **batch,
            generation_config=gen_cfg,
            max_new_tokens=max_new_tokens,
            repetition_penalty=1.05,
            use_cache=True,
            pad_token_id=tokenizer.eos_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )

    new_tokens = output[0][batch["input_ids"].shape[1]:]
    return tokenizer.decode(new_tokens, skip_special_tokens=True).strip()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True, help="Path to your NLP Project folder")
    parser.add_argument("--model_id", default="Qwen/Qwen2.5-1.5B-Instruct")
    parser.add_argument("--samples_per_split", type=int, default=8)
    parser.add_argument("--top_k", type=int, default=2)
    parser.add_argument("--max_new_tokens", type=int, default=90)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    repo = Path(args.repo).expanduser().resolve()

    wiki_docs_path = repo / "outputs" / "wiki_docs.jsonl"
    grounded_turns_path = repo / "outputs" / "fs_grounded_turns.jsonl"

    if not wiki_docs_path.exists():
        raise FileNotFoundError(f"Missing file: {wiki_docs_path}")
    if not grounded_turns_path.exists():
        raise FileNotFoundError(f"Missing file: {grounded_turns_path}")

    wiki_docs = load_jsonl(wiki_docs_path)
    grounded_turns = load_jsonl(grounded_turns_path)
    doc_map = {d["doc_id"]: d for d in wiki_docs}
    convs = load_conversations(repo)

    # Keep only clean wiki-only validation examples
    clean = [
        t for t in grounded_turns
        if t.get("split") in {"valid_freq", "valid_rare"}
        and len(t.get("gold_doc_ids", [])) > 0
        and not t.get("uses_personal_knowledge", False)
        and not has_prefix(t.get("knowledge_source_labels", []), "AS")
    ]

    by_split: dict[str, list[dict[str, Any]]] = {"valid_freq": [], "valid_rare": []}
    for t in clean:
        by_split[t["split"]].append(t)

    rng = random.Random(args.seed)
    eval_set: list[dict[str, Any]] = []

    for split in ["valid_freq", "valid_rare"]:
        items = by_split[split]
        rng.shuffle(items)
        picked = items[:args.samples_per_split]

        for item in picked:
            conv_key = f"{split}::{item['conv_id']}"
            conv = convs[conv_key]
            history_text = build_history_text(conv, item["turn_index"], max_prev_turns=2)

            gold_entities = []
            gold_previews = []

            for doc_id in item["gold_doc_ids"]:
                doc = doc_map.get(doc_id)
                if doc:
                    gold_entities.append(doc.get("entity"))
                    gold_previews.append(short_text(doc.get("text", ""), 180))

            eval_set.append({
                "eval_id": f"{split}::{item['conv_id']}::{item['turn_index']}",
                "split": split,
                "conv_id": item["conv_id"],
                "turn_index": item["turn_index"],
                "query": item["message"],
                "history_text": history_text,
                "gold_doc_ids": item["gold_doc_ids"],
                "gold_entities": gold_entities,
                "gold_previews": gold_previews,
            })

    retriever = BM25Retriever(wiki_docs)

    print(f"Evaluation examples selected: {len(eval_set)}")
    print("Loading model once for batch evaluation...")
    tokenizer, model = load_model_and_tokenizer(args.model_id)
    print("Model loaded.")

    results: list[dict[str, Any]] = []

    for i, ex in enumerate(eval_set, start=1):
        retrieval_query = f"{ex['history_text']} {ex['query']}".strip()
        top_docs = retriever.search(retrieval_query, top_k=args.top_k)
        messages = build_messages(ex["query"], ex["history_text"], top_docs)
        answer = generate_answer(
            tokenizer=tokenizer,
            model=model,
            messages=messages,
            max_new_tokens=args.max_new_tokens,
        )

        result = {
            "eval_id": ex["eval_id"],
            "split": ex["split"],
            "conv_id": ex["conv_id"],
            "turn_index": ex["turn_index"],
            "query": ex["query"],
            "history_text": ex["history_text"],
            "gold_doc_ids": ex["gold_doc_ids"],
            "gold_entities": ex["gold_entities"],
            "retrieved_doc_ids": [d["doc_id"] for d in top_docs],
            "retrieved_entities": [d.get("entity") for d in top_docs],
            "retrieved_previews": [short_text(d.get("text", ""), 180) for d in top_docs],
            "model_answer": answer,
            "groundedness_1_5": "",
            "relevance_1_5": "",
            "coherence_1_5": "",
            "abstention_ok_0_1": "",
            "notes": "",
        }
        results.append(result)

        print(f"[{i}/{len(eval_set)}] {ex['split']} | {short_text(ex['query'], 70)}")

    outputs_dir = repo / "outputs"

    save_jsonl(outputs_dir / "checkpoint_07_eval_set.jsonl", eval_set)
    save_jsonl(outputs_dir / "checkpoint_07_eval_results.jsonl", results)

    csv_path = outputs_dir / "checkpoint_07_eval_results.csv"
    fieldnames = [
        "eval_id",
        "split",
        "conv_id",
        "turn_index",
        "query",
        "history_text",
        "gold_doc_ids",
        "gold_entities",
        "retrieved_doc_ids",
        "retrieved_entities",
        "model_answer",
        "groundedness_1_5",
        "relevance_1_5",
        "coherence_1_5",
        "abstention_ok_0_1",
        "notes",
    ]

    with csv_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in results:
            row_copy = dict(row)
            for key in ["gold_doc_ids", "gold_entities", "retrieved_doc_ids", "retrieved_entities", "retrieved_previews"]:
                row_copy[key] = json.dumps(row_copy[key], ensure_ascii=False)
            writer.writerow(row_copy)

    summary = {
        "model_id": args.model_id,
        "samples_per_split": args.samples_per_split,
        "num_examples": len(results),
        "split_counts": {
            "valid_freq": sum(1 for x in results if x["split"] == "valid_freq"),
            "valid_rare": sum(1 for x in results if x["split"] == "valid_rare"),
        },
        "files": {
            "eval_set_jsonl": str(outputs_dir / "checkpoint_07_eval_set.jsonl"),
            "eval_results_jsonl": str(outputs_dir / "checkpoint_07_eval_results.jsonl"),
            "eval_results_csv": str(csv_path),
        },
        "rating_guide": {
            "groundedness_1_5": "1 = unsupported, 5 = clearly supported by retrieved evidence",
            "relevance_1_5": "1 = off-topic, 5 = directly answers the question",
            "coherence_1_5": "1 = broken/confused, 5 = clear and fluent",
            "abstention_ok_0_1": "1 = good refusal when evidence is weak, else 0",
        }
    }

    save_json(outputs_dir / "checkpoint_07_eval_summary.json", summary)

    print("\nDone.")
    print(f"Saved: {outputs_dir / 'checkpoint_07_eval_set.jsonl'}")
    print(f"Saved: {outputs_dir / 'checkpoint_07_eval_results.jsonl'}")
    print(f"Saved: {csv_path}")
    print(f"Saved: {outputs_dir / 'checkpoint_07_eval_summary.json'}")
    print("\nNext step:")
    print("Open checkpoint_07_eval_results.csv and fill the rating columns.")


if __name__ == "__main__":
    main()