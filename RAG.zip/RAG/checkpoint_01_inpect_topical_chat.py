from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


SPLITS = ["train", "valid_freq", "valid_rare", "test_freq", "test_rare"]


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def short_text(value: Any, limit: int = 300) -> str:
    if value is None:
        return "None"
    if isinstance(value, str):
        text = value.replace("\n", " ").strip()
    else:
        text = json.dumps(value, ensure_ascii=False)
    if len(text) <= limit:
        return text
    return text[:limit] + " ..."


def first_key_with_prefix(d: dict[str, Any], prefix: str) -> str | None:
    for k in d.keys():
        if k.startswith(prefix):
            return k
    return None


def print_section(title: str) -> None:
    print("\n" + "=" * 90)
    print(title)
    print("=" * 90)


def check_expected_files(repo_root: Path) -> None:
    print_section("EXPECTED FILE CHECK")

    conv_dir = repo_root / "conversations"
    pre_dir = repo_root / "reading_sets" / "pre-build"
    post_dir = repo_root / "reading_sets" / "post-build"

    print(f"Repo root           : {repo_root}")
    print(f"conversations/      : {'FOUND' if conv_dir.exists() else 'MISSING'} -> {conv_dir}")
    print(f"reading_sets/pre-build/  : {'FOUND' if pre_dir.exists() else 'MISSING'} -> {pre_dir}")
    print(f"reading_sets/post-build/ : {'FOUND' if post_dir.exists() else 'MISSING'} -> {post_dir}")

    print("\nConversation split files:")
    for split in SPLITS:
        p = conv_dir / f"{split}.json"
        print(f"  {split:10s} : {'FOUND' if p.exists() else 'MISSING'} -> {p.name}")

    print("\nReading-set pre-build split files:")
    for split in SPLITS:
        p = pre_dir / f"{split}.json"
        print(f"  {split:10s} : {'FOUND' if p.exists() else 'MISSING'} -> {p.name}")

    print("\nReading-set post-build split files:")
    for split in SPLITS:
        p = post_dir / f"{split}.json"
        print(f"  {split:10s} : {'FOUND' if p.exists() else 'MISSING'} -> {p.name}")


def inspect_conversation(repo_root: Path, split: str) -> str:
    print_section(f"SAMPLE CONVERSATION FROM conversations/{split}.json")

    conv_path = repo_root / "conversations" / f"{split}.json"
    conv_data = load_json(conv_path)

    conv_id = next(iter(conv_data))
    conv = conv_data[conv_id]

    print(f"conversation_id : {conv_id}")
    print(f"article_url     : {conv.get('article_url')}")
    print(f"config          : {conv.get('config')}")
    print(f"num_turns       : {len(conv.get('content', []))}")

    print("\nFirst 6 turns:")
    for i, turn in enumerate(conv.get("content", [])[:6], start=1):
        print(f"\nTurn {i}")
        print(f"  agent            : {turn.get('agent')}")
        print(f"  knowledge_source : {turn.get('knowledge_source')}")
        print(f"  message          : {short_text(turn.get('message'), 220)}")

    return conv_id


def inspect_reading_entry(file_path: Path, conv_id: str, label: str) -> None:
    print_section(f"SAMPLE READING-SET ENTRY FROM {label}")

    data = load_json(file_path)
    if conv_id not in data:
        print(f"{conv_id} not found in {file_path.name}")
        return

    entry = data[conv_id]
    print(f"conversation_id : {conv_id}")
    print(f"config          : {entry.get('config')}")

    agent_1 = entry.get("agent_1", {})
    agent_2 = entry.get("agent_2", {})
    article = entry.get("article", {})

    print("\nTop-level keys:")
    print(f"  agent_1 keys: {list(agent_1.keys())[:10]}")
    print(f"  agent_2 keys: {list(agent_2.keys())[:10]}")
    print(f"  article keys: {list(article.keys())[:10]}")

    fs1 = first_key_with_prefix(agent_1, "FS")
    if fs1 is not None:
        fs_obj = agent_1[fs1]
        print(f"\nSample agent_1 {fs1}:")
        if isinstance(fs_obj, dict):
            for k in list(fs_obj.keys())[:10]:
                print(f"  {k}: {short_text(fs_obj.get(k), 220)}")
        else:
            print(f"  value: {short_text(fs_obj, 220)}")

    as1 = first_key_with_prefix(article, "AS")
    if article:
        print("\nSample article fields:")
        for k in ["headline", "url", as1]:
            if k and k in article:
                print(f"  {k}: {short_text(article.get(k), 220)}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--repo",
        required=True,
        help="Path to local Topical-Chat repo root"
    )
    parser.add_argument(
        "--split",
        default="valid_freq",
        choices=SPLITS,
        help="Which split to inspect"
    )
    args = parser.parse_args()

    repo_root = Path(args.repo).expanduser().resolve()
    if not repo_root.exists():
        raise FileNotFoundError(f"Repo path does not exist: {repo_root}")

    check_expected_files(repo_root)

    conv_id = inspect_conversation(repo_root, args.split)

    pre_path = repo_root / "reading_sets" / "pre-build" / f"{args.split}.json"
    post_path = repo_root / "reading_sets" / "post-build" / f"{args.split}.json"

    if pre_path.exists():
        inspect_reading_entry(pre_path, conv_id, f"reading_sets/pre-build/{args.split}.json")
    else:
        print_section("PRE-BUILD CHECK")
        print("No pre-build file found for that split.")

    if post_path.exists():
        inspect_reading_entry(post_path, conv_id, f"reading_sets/post-build/{args.split}.json")
    else:
        print_section("POST-BUILD CHECK")
        print("No post-build file found for that split.")

    print_section("CHECKPOINT 1 DONE")
    print("What I need from you next:")
    print("1. Whether post-build exists or not")
    print("2. Whether the pre-build sample already contains usable text")
    print("3. Paste the terminal output here")


if __name__ == "__main__":
    main()
