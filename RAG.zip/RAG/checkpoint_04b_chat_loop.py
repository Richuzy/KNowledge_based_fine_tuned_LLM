from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from checkpoint_04_rag_generate import (
    load_jsonl,
    BM25Retriever,
    build_messages,
    load_model_and_tokenizer,
    generate_answer,
)


def short_text(text: Any, limit: int = 220) -> str:
    if text is None:
        return "None"
    if not isinstance(text, str):
        text = json.dumps(text, ensure_ascii=False)
    text = text.replace("\n", " ").strip()
    return text if len(text) <= limit else text[:limit] + " ..."


def history_to_text(chat_history: list[dict[str, str]], max_turns: int = 4) -> str:
    recent = chat_history[-max_turns:]
    lines = []
    for turn in recent:
        role = turn["role"].capitalize()
        lines.append(f"{role}: {turn['content']}")
    return "\n".join(lines)


def append_jsonl(path: Path, record: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True, help="Path to your NLP Project folder")
    parser.add_argument("--model_id", required=True, help="Hugging Face model id")
    parser.add_argument("--top_k", type=int, default=2)
    parser.add_argument("--max_new_tokens", type=int, default=100)
    parser.add_argument("--max_history_turns", type=int, default=4)
    args = parser.parse_args()

    repo = Path(args.repo).expanduser().resolve()
    wiki_docs_path = repo / "outputs" / "wiki_docs.jsonl"

    if not wiki_docs_path.exists():
        raise FileNotFoundError(f"Missing file: {wiki_docs_path}")

    print("\nLoading wiki docs...")
    wiki_docs = load_jsonl(wiki_docs_path)
    retriever = BM25Retriever(wiki_docs)
    print(f"Indexed docs: {len(wiki_docs)}")

    print("\nLoading model once...")
    tokenizer, model = load_model_and_tokenizer(args.model_id)
    print("Model loaded.\n")

    print("=" * 90)
    print("LOCAL RAG CHAT")
    print(f"Model: {args.model_id}")
    print("Type your question and press Enter.")
    print("Type 'exit' or 'quit' to stop.")
    print("=" * 90)

    chat_history: list[dict[str, str]] = []
    session_path = repo / "outputs" / "checkpoint_04b_chat_session.jsonl"

    while True:
        query = input("\nYou: ").strip()

        if not query:
            continue
        if query.lower() in {"exit", "quit"}:
            print("Exiting chat.")
            break

        history_text = history_to_text(chat_history, max_turns=args.max_history_turns)
        retrieval_query = f"{history_text} {query}".strip()

        top_docs = retriever.search(retrieval_query, top_k=args.top_k)
        messages = build_messages(query, history_text, top_docs)

        print("\nRetrieved docs:")
        if not top_docs:
            print("  No evidence retrieved.")
        else:
            for i, doc in enumerate(top_docs, start=1):
                print(f"  [{i}] {doc['doc_id']} | entity={doc['entity']} | score={doc['score']:.4f}")
                print(f"      {short_text(doc['text'], 160)}")

        answer = generate_answer(
            tokenizer=tokenizer,
            model=model,
            messages=messages,
            max_new_tokens=args.max_new_tokens,
        )

        print(f"\nBot: {answer}")

        chat_history.append({"role": "user", "content": query})
        chat_history.append({"role": "assistant", "content": answer})

        append_jsonl(session_path, {
            "model_id": args.model_id,
            "query": query,
            "history_used": history_text,
            "retrieved_docs": top_docs,
            "answer": answer,
        })

    print(f"\nChat session saved to:\n{session_path}")


if __name__ == "__main__":
    main()