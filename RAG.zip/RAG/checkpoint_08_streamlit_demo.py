from __future__ import annotations

import copy
import json
import re
from pathlib import Path
from typing import Any

import streamlit as st
import torch

from checkpoint_04_rag_generate import load_jsonl, BM25Retriever, load_model_and_tokenizer


TOKEN_PATTERN = re.compile(r"[a-z0-9]+")
STOPWORDS = {
    "a", "an", "the", "is", "are", "was", "were", "am", "be", "been", "being",
    "do", "does", "did", "what", "who", "when", "where", "why", "how",
    "i", "you", "he", "she", "it", "we", "they", "me", "him", "her", "them",
    "my", "your", "his", "their", "our", "this", "that", "these", "those",
    "to", "of", "in", "on", "for", "with", "about", "and", "or", "but",
    "at", "by", "from", "as", "if", "then", "than", "so", "because",
    "can", "could", "would", "should", "will", "just", "really", "very",
    "have", "has", "had", "there", "here", "into", "out", "up", "down",
}


def tokenize(text: str) -> list[str]:
    if not text:
        return []
    return TOKEN_PATTERN.findall(text.lower())


def content_tokens(text: str) -> list[str]:
    toks = tokenize(text)
    return [t for t in toks if t not in STOPWORDS and len(t) > 1]


def short_text(text: Any, limit: int = 220) -> str:
    if text is None:
        return "None"
    if not isinstance(text, str):
        text = json.dumps(text, ensure_ascii=False)
    text = text.replace("\n", " ").strip()
    return text if len(text) <= limit else text[:limit] + " ..."


def history_to_text(messages: list[dict[str, Any]], max_turns: int = 4) -> str:
    usable = [m for m in messages if m["role"] in {"user", "assistant"}]
    recent = usable[-(max_turns * 2):]

    lines = []
    for msg in recent:
        role = "User" if msg["role"] == "user" else "Assistant"
        lines.append(f"{role}: {msg['content']}")
    return "\n".join(lines)


def evidence_gate(query: str, docs: list[dict[str, Any]]) -> tuple[bool, str]:
    if not docs:
        return False, "No retrieved docs."

    q = set(content_tokens(query))
    top = docs[0]
    d = set(content_tokens(f"{top.get('entity', '')} {top.get('text', '')}"))
    overlap = len(q & d)

    if overlap >= 1:
        return True, f"Token overlap={overlap}"

    return False, "Weak lexical match."


def build_messages(query: str, history: str, retrieved_docs: list[dict[str, Any]]) -> list[dict[str, str]]:
    evidence_blocks = []
    for i, doc in enumerate(retrieved_docs, start=1):
        evidence_blocks.append(
            f"[{i}] Entity: {doc.get('entity')}\n"
            f"Document ID: {doc.get('doc_id')}\n"
            f"Text: {doc.get('text')}"
        )

    evidence_text = "\n\n".join(evidence_blocks) if evidence_blocks else "(no evidence)"
    history_text = history.strip() if history.strip() else "(none)"

    system_prompt = (
        "You are a knowledge-grounded explainer chatbot. "
        "Use only the retrieved evidence. "
        "Do not invent facts. "
        "Do not claim personal opinions, preferences, habits, or experiences. "
        "If the user asks what you like, think, enjoy, or watch, say that you do not have personal opinions or experiences, "
        "then answer factually only from the evidence if possible. "
        "If the evidence is weak or insufficient, say that you do not have enough grounded evidence."
    )

    user_prompt = (
        f"Conversation history:\n{history_text}\n\n"
        f"Retrieved evidence:\n{evidence_text}\n\n"
        f"User question:\n{query}\n\n"
        f"Requirements:\n"
        f"- Answer in 2 to 4 sentences.\n"
        f"- Use only the evidence above.\n"
        f"- Never pretend to have personal preferences.\n"
        f"- End with: Sources: [1], [2]\n"
        f"  Only include source numbers that were actually useful.\n"
    )

    return [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]


def format_prompt(tokenizer, messages: list[dict[str, str]]) -> str:
    if hasattr(tokenizer, "apply_chat_template"):
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
        )

    parts = []
    for msg in messages:
        parts.append(f"{msg['role'].upper()}:\n{msg['content']}\n")
    parts.append("ASSISTANT:\n")
    return "\n".join(parts)


def generate_answer(tokenizer, model, messages: list[dict[str, str]], max_new_tokens: int = 90) -> str:
    prompt = format_prompt(tokenizer, messages)
    batch = tokenizer(prompt, return_tensors="pt")
    model_device = next(model.parameters()).device
    batch = {k: v.to(model_device) for k, v in batch.items()}

    gen_cfg = copy.deepcopy(model.generation_config)
    gen_cfg.do_sample = False

    for attr in ("temperature", "top_p", "top_k"):
        if hasattr(gen_cfg, attr):
            try:
                setattr(gen_cfg, attr, None)
            except Exception:
                pass

    with torch.no_grad():
        output = model.generate(
            **batch,
            generation_config=gen_cfg,
            max_new_tokens=max_new_tokens,
            repetition_penalty=1.05,
            use_cache=True,
            pad_token_id=tokenizer.eos_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )

    new_tokens = output[0][batch["input_ids"].shape[1]:]
    return tokenizer.decode(new_tokens, skip_special_tokens=True).strip()


@st.cache_resource
def load_resources(repo_path: str, model_id: str):
    repo = Path(repo_path).expanduser().resolve()
    wiki_docs_path = repo / "outputs" / "wiki_docs.jsonl"

    if not wiki_docs_path.exists():
        raise FileNotFoundError(f"Missing file: {wiki_docs_path}")

    wiki_docs = load_jsonl(wiki_docs_path)
    retriever = BM25Retriever(wiki_docs)
    tokenizer, model = load_model_and_tokenizer(model_id)
    return wiki_docs, retriever, tokenizer, model


def main() -> None:
    st.set_page_config(page_title="Knowledge-Grounded Explainer Chatbot", layout="wide")
    st.title("Knowledge-Grounded Explainer Chatbot")
    st.caption("RAG over Topical-Chat wiki corpus (FS-only version)")

    default_repo = str(Path.cwd())

    with st.sidebar:
        st.header("Settings")
        repo_path = st.text_input("Project folder", value=default_repo)
        model_id = st.text_input("Model ID", value="Qwen/Qwen2.5-1.5B-Instruct")
        top_k = st.slider("Top K docs", min_value=1, max_value=5, value=2)
        max_new_tokens = st.slider("Max new tokens", min_value=40, max_value=140, value=90, step=10)
        max_history_turns = st.slider("History turns for prompt", min_value=0, max_value=6, value=4)

        if st.button("Clear chat"):
            st.session_state.messages = []
            st.rerun()

    try:
        wiki_docs, retriever, tokenizer, model = load_resources(repo_path, model_id)
    except Exception as e:
        st.error(f"Load failed: {e}")
        st.stop()

    st.sidebar.success(f"Indexed docs: {len(wiki_docs)}")
    st.sidebar.info("Model loads once and stays cached.")

    if "messages" not in st.session_state:
        st.session_state.messages = []

    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])
            if msg["role"] == "assistant" and msg.get("retrieved_docs"):
                with st.expander("Retrieved evidence"):
                    st.write(f"Gate: {msg.get('gate_reason', '')}")
                    for i, doc in enumerate(msg["retrieved_docs"], start=1):
                        st.markdown(
                            f"**[{i}] {doc.get('entity')}**  \n"
                            f"`{doc.get('doc_id')}`  \n"
                            f"Score: {doc.get('score', 0):.4f}"
                        )
                        st.write(short_text(doc.get("text", ""), 500))

    user_input = st.chat_input("Ask a question")

    if user_input:
        st.session_state.messages.append({"role": "user", "content": user_input})

        with st.chat_message("user"):
            st.markdown(user_input)

        history_text = history_to_text(st.session_state.messages[:-1], max_turns=max_history_turns)
        retrieved_docs = retriever.search(user_input, top_k=top_k)
        ok, reason = evidence_gate(user_input, retrieved_docs)

        if not ok:
            answer = "I do not have enough grounded evidence to answer that confidently."
        else:
            messages = build_messages(user_input, history_text, retrieved_docs)
            answer = generate_answer(
                tokenizer=tokenizer,
                model=model,
                messages=messages,
                max_new_tokens=max_new_tokens,
            )

        assistant_msg = {
            "role": "assistant",
            "content": answer,
            "retrieved_docs": retrieved_docs,
            "gate_reason": reason,
        }
        st.session_state.messages.append(assistant_msg)

        with st.chat_message("assistant"):
            st.markdown(answer)
            with st.expander("Retrieved evidence", expanded=True):
                st.write(f"Gate: {reason}")
                for i, doc in enumerate(retrieved_docs, start=1):
                    st.markdown(
                        f"**[{i}] {doc.get('entity')}**  \n"
                        f"`{doc.get('doc_id')}`  \n"
                        f"Score: {doc.get('score', 0):.4f}"
                    )
                    st.write(short_text(doc.get("text", ""), 500))


if __name__ == "__main__":
    main()