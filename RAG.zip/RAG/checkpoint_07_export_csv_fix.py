from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True, help="Path to your NLP Project folder")
    args = parser.parse_args()

    repo = Path(args.repo).expanduser().resolve()
    outputs_dir = repo / "outputs"

    jsonl_path = outputs_dir / "checkpoint_07_eval_results.jsonl"
    csv_path = outputs_dir / "checkpoint_07_eval_results.csv"
    summary_path = outputs_dir / "checkpoint_07_eval_summary.json"

    if not jsonl_path.exists():
        raise FileNotFoundError(f"Missing file: {jsonl_path}")

    rows = load_jsonl(jsonl_path)

    fieldnames = [
        "eval_id",
        "split",
        "conv_id",
        "turn_index",
        "query",
        "history_text",
        "gold_doc_ids",
        "gold_entities",
        "retrieved_doc_ids",
        "retrieved_entities",
        "retrieved_previews",
        "model_answer",
        "groundedness_1_5",
        "relevance_1_5",
        "coherence_1_5",
        "abstention_ok_0_1",
        "notes",
    ]

    with csv_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()

        for row in rows:
            row_copy = dict(row)

            for key in [
                "gold_doc_ids",
                "gold_entities",
                "retrieved_doc_ids",
                "retrieved_entities",
                "retrieved_previews",
            ]:
                row_copy[key] = json.dumps(row_copy.get(key, []), ensure_ascii=False)

            for key in [
                "groundedness_1_5",
                "relevance_1_5",
                "coherence_1_5",
                "abstention_ok_0_1",
                "notes",
            ]:
                row_copy.setdefault(key, "")

            writer.writerow(row_copy)

    summary = {
        "num_examples": len(rows),
        "split_counts": {
            "valid_freq": sum(1 for r in rows if r.get("split") == "valid_freq"),
            "valid_rare": sum(1 for r in rows if r.get("split") == "valid_rare"),
        },
        "csv_path": str(csv_path),
        "jsonl_path": str(jsonl_path),
    }
    save_json(summary_path, summary)

    print("CSV export fixed.")
    print(f"Read from : {jsonl_path}")
    print(f"Wrote CSV : {csv_path}")
    print(f"Wrote summary: {summary_path}")


if __name__ == "__main__":
    main()