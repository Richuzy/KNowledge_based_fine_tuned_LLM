from __future__ import annotations

import argparse
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig


MODEL_ID = "allenai/OLMo-2-1124-7B-Instruct"
TOKEN_PATTERN = re.compile(r"[a-z0-9]+")


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    return records


def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)


def tokenize(text: str) -> list[str]:
    if not text:
        return []
    return TOKEN_PATTERN.findall(text.lower())


def short_text(text: Any, limit: int = 260) -> str:
    if text is None:
        return "None"
    if not isinstance(text, str):
        text = json.dumps(text, ensure_ascii=False)
    text = text.replace("\n", " ").strip()
    return text if len(text) <= limit else text[:limit] + " ..."


class BM25Retriever:
    def __init__(self, docs: list[dict[str, Any]], k1: float = 1.5, b: float = 0.75):
        self.docs = docs
        self.k1 = k1
        self.b = b

        self.doc_freqs: list[Counter[str]] = []
        self.doc_lens: list[int] = []
        self.idf: dict[str, float] = {}

        document_frequency: defaultdict[str, int] = defaultdict(int)
        total_length = 0

        for doc in self.docs:
            indexed_text = f"{doc.get('entity', '')}. {doc.get('text', '')}"
            tokens = tokenize(indexed_text)
            freq = Counter(tokens)

            self.doc_freqs.append(freq)
            self.doc_lens.append(len(tokens))
            total_length += len(tokens)

            for term in freq.keys():
                document_frequency[term] += 1

        self.avgdl = total_length / len(self.docs) if self.docs else 0.0
        num_docs = len(self.docs)

        for term, df in document_frequency.items():
            self.idf[term] = math.log(1.0 + (num_docs - df + 0.5) / (df + 0.5))

    def search(self, query: str, top_k: int = 3) -> list[dict[str, Any]]:
        query_tokens = tokenize(query)
        if not query_tokens:
            return []

        unique_query_terms = list(dict.fromkeys(query_tokens))
        results: list[dict[str, Any]] = []

        for i, doc in enumerate(self.docs):
            freq = self.doc_freqs[i]
            doc_len = self.doc_lens[i]

            denom_base = self.k1 * (1.0 - self.b + self.b * doc_len / self.avgdl) if self.avgdl > 0 else self.k1

            score = 0.0
            for term in unique_query_terms:
                tf = freq.get(term, 0)
                if tf == 0:
                    continue
                idf = self.idf.get(term, 0.0)
                score += idf * ((tf * (self.k1 + 1.0)) / (tf + denom_base))

            if score > 0.0:
                results.append({
                    "doc_id": doc["doc_id"],
                    "entity": doc.get("entity"),
                    "score": float(score),
                    "text": doc.get("text", "")
                })

        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:top_k]


def build_messages(query: str, history: str, retrieved_docs: list[dict[str, Any]]) -> list[dict[str, str]]:
    evidence_blocks = []
    for i, doc in enumerate(retrieved_docs, start=1):
        evidence_blocks.append(
            f"[{i}] Entity: {doc.get('entity')}\n"
            f"Document ID: {doc.get('doc_id')}\n"
            f"Text: {doc.get('text')}"
        )

    evidence_text = "\n\n".join(evidence_blocks) if evidence_blocks else "(no evidence retrieved)"
    history_text = history.strip() if history.strip() else "(none)"

    system_prompt = (
        "You are a knowledge-grounded explainer chatbot. "
        "Answer only using the retrieved evidence. "
        "If the evidence is insufficient, say that you do not have enough grounded evidence. "
        "Keep the answer short, clear, and factual. "
        "End with a line in this format: Sources: [1], [2]"
    )

    user_prompt = (
        f"Conversation history:\n{history_text}\n\n"
        f"Retrieved evidence:\n{evidence_text}\n\n"
        f"User question:\n{query}\n\n"
        f"Requirements:\n"
        f"- Use only the retrieved evidence.\n"
        f"- Do not invent facts.\n"
        f"- Explain in 3 to 6 sentences.\n"
        f"- If evidence is weak, say so clearly.\n"
    )

    return [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]


def format_prompt(tokenizer: AutoTokenizer, messages: list[dict[str, str]]) -> str:
    if hasattr(tokenizer, "apply_chat_template"):
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True
        )

    parts = []
    for msg in messages:
        parts.append(f"{msg['role'].upper()}:\n{msg['content']}\n")
    parts.append("ASSISTANT:\n")
    return "\n".join(parts)


def load_model_and_tokenizer(model_id: str):
    if not torch.cuda.is_available():
        raise RuntimeError(
            "CUDA is not available. For this checkpoint, you should use GPU 4-bit loading. "
            "Fix Torch/CUDA first."
        )

    quant_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.float16,
        bnb_4bit_use_double_quant=True,
    )

    tokenizer = AutoTokenizer.from_pretrained(
        model_id,
        trust_remote_code=True,
    )

    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        model_id,
        quantization_config=quant_config,
        device_map="auto",
        torch_dtype=torch.float16,
        trust_remote_code=True,
    )

    model.eval()
    return tokenizer, model


def generate_answer(
    tokenizer: AutoTokenizer,
    model: AutoModelForCausalLM,
    messages: list[dict[str, str]],
    max_new_tokens: int = 160,
) -> str:
    prompt = format_prompt(tokenizer, messages)
    batch = tokenizer(prompt, return_tensors="pt")

    model_device = next(model.parameters()).device
    batch = {k: v.to(model_device) for k, v in batch.items()}

    with torch.no_grad():
        output = model.generate(
            **batch,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            pad_token_id=tokenizer.eos_token_id,
            eos_token_id=tokenizer.eos_token_id,
            repetition_penalty=1.05,
        )

    new_tokens = output[0][batch["input_ids"].shape[1]:]
    answer = tokenizer.decode(new_tokens, skip_special_tokens=True).strip()
    return answer


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True, help="Path to your NLP Project folder")
    parser.add_argument("--query", required=True, help="User question")
    parser.add_argument("--history", default="", help="Optional chat history")
    parser.add_argument("--top_k", type=int, default=3, help="Number of retrieved docs")
    parser.add_argument("--max_new_tokens", type=int, default=140)
    parser.add_argument("--model_id", default=MODEL_ID)
    parser.add_argument("--dry_run", action="store_true", help="Skip model loading and only print retrieval/prompt")
    args = parser.parse_args()

    repo = Path(args.repo).expanduser().resolve()
    wiki_docs_path = repo / "outputs" / "wiki_docs.jsonl"

    if not wiki_docs_path.exists():
        raise FileNotFoundError(f"Missing file: {wiki_docs_path}")

    wiki_docs = load_jsonl(wiki_docs_path)
    retriever = BM25Retriever(wiki_docs)

    retrieval_query = f"{args.history} {args.query}".strip()
    top_docs = retriever.search(retrieval_query, top_k=args.top_k)
    messages = build_messages(args.query, args.history, top_docs)

    print("\n" + "=" * 100)
    print("CHECKPOINT 4 - RETRIEVAL")
    print("=" * 100)
    print(f"Query: {args.query}")
    print(f"History: {args.history if args.history else '(none)'}")
    print(f"Top K: {args.top_k}")

    for i, doc in enumerate(top_docs, start=1):
        print("\n" + "-" * 100)
        print(f"[{i}] doc_id={doc['doc_id']} | entity={doc['entity']} | score={doc['score']:.4f}")
        print(short_text(doc["text"], 500))

    outputs_dir = repo / "outputs"
    prompt_preview = {
        "query": args.query,
        "history": args.history,
        "retrieved_docs": top_docs,
        "messages": messages,
    }
    save_json(outputs_dir / "checkpoint_04_prompt_preview.json", prompt_preview)

    if args.dry_run:
        print("\nDry run only. Prompt preview saved.")
        print(outputs_dir / "checkpoint_04_prompt_preview.json")
        return

    print("\n" + "=" * 100)
    print("LOADING MODEL")
    print("=" * 100)
    print(f"CUDA available: {torch.cuda.is_available()}")
    print(f"GPU: {torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU only'}")
    print(f"Model: {args.model_id}")

    tokenizer, model = load_model_and_tokenizer(args.model_id)

    print("\n" + "=" * 100)
    print("GENERATING ANSWER")
    print("=" * 100)
    answer = generate_answer(
        tokenizer=tokenizer,
        model=model,
        messages=messages,
        max_new_tokens=args.max_new_tokens,
    )

    print(answer)

    result = {
        "query": args.query,
        "history": args.history,
        "top_k": args.top_k,
        "max_new_tokens": args.max_new_tokens,
        "model_id": args.model_id,
        "retrieved_docs": top_docs,
        "answer": answer,
    }
    save_json(outputs_dir / "checkpoint_04_last_response.json", result)

    print("\nSaved files:")
    print(outputs_dir / "checkpoint_04_prompt_preview.json")
    print(outputs_dir / "checkpoint_04_last_response.json")


if __name__ == "__main__":
    main()