from __future__ import annotations

import argparse
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


TOP_KS = [1, 3, 5, 10]
TOKEN_PATTERN = re.compile(r"[a-z0-9]+")


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    return records


def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)


def save_jsonl(path: Path, records: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for record in records:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")


def tokenize(text: str) -> list[str]:
    if not text:
        return []
    return TOKEN_PATTERN.findall(text.lower())


def short_text(text: Any, limit: int = 240) -> str:
    if text is None:
        return "None"
    if not isinstance(text, str):
        text = json.dumps(text, ensure_ascii=False)
    text = text.replace("\n", " ").strip()
    return text if len(text) <= limit else text[:limit] + " ..."


def has_prefix(labels: list[str], prefix: str) -> bool:
    return any(isinstance(x, str) and x.startswith(prefix) for x in labels)


class BM25Retriever:
    def __init__(self, docs: list[dict[str, Any]], k1: float = 1.5, b: float = 0.75):
        self.docs = docs
        self.k1 = k1
        self.b = b

        self.doc_freqs: list[Counter[str]] = []
        self.doc_lens: list[int] = []
        self.idf: dict[str, float] = {}

        document_frequency: defaultdict[str, int] = defaultdict(int)
        total_length = 0

        for doc in self.docs:
            indexed_text = f"{doc.get('entity', '')}. {doc.get('text', '')}"
            tokens = tokenize(indexed_text)
            freq = Counter(tokens)

            self.doc_freqs.append(freq)
            self.doc_lens.append(len(tokens))
            total_length += len(tokens)

            for term in freq.keys():
                document_frequency[term] += 1

        self.avgdl = total_length / len(self.docs) if self.docs else 0.0
        num_docs = len(self.docs)

        for term, df in document_frequency.items():
            self.idf[term] = math.log(1.0 + (num_docs - df + 0.5) / (df + 0.5))

    def search(self, query: str, top_k: int = 5) -> list[dict[str, Any]]:
        query_tokens = tokenize(query)
        if not query_tokens:
            return []

        unique_query_terms = list(dict.fromkeys(query_tokens))
        results: list[dict[str, Any]] = []

        for i, doc in enumerate(self.docs):
            freq = self.doc_freqs[i]
            doc_len = self.doc_lens[i]

            denom_base = self.k1 * (1.0 - self.b + self.b * doc_len / self.avgdl) if self.avgdl > 0 else self.k1

            score = 0.0
            for term in unique_query_terms:
                tf = freq.get(term, 0)
                if tf == 0:
                    continue
                idf = self.idf.get(term, 0.0)
                score += idf * ((tf * (self.k1 + 1.0)) / (tf + denom_base))

            if score > 0.0:
                results.append({
                    "doc_id": doc["doc_id"],
                    "entity": doc.get("entity"),
                    "score": score,
                    "text": doc.get("text", "")
                })

        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:top_k]


def compute_metrics(eval_turns: list[dict[str, Any]], retriever: BM25Retriever) -> tuple[dict[str, Any], list[dict[str, Any]], list[dict[str, Any]]]:
    per_split: dict[str, dict[str, Any]] = {}
    sample_examples: list[dict[str, Any]] = []
    all_results: list[dict[str, Any]] = []

    overall_total = 0
    overall_hits = {k: 0 for k in TOP_KS}

    for turn in eval_turns:
        split = turn["split"]
        if split not in per_split:
            per_split[split] = {
                "num_turns": 0,
                "hits": {k: 0 for k in TOP_KS}
            }

        query = turn.get("message", "") or ""
        gold_doc_ids = list(dict.fromkeys(turn.get("gold_doc_ids", [])))
        hits = retriever.search(query, top_k=max(TOP_KS))
        retrieved_ids = [x["doc_id"] for x in hits]

        hit_by_k = {}
        for k in TOP_KS:
            ok = any(doc_id in set(gold_doc_ids) for doc_id in retrieved_ids[:k])
            hit_by_k[k] = ok

        per_split[split]["num_turns"] += 1
        overall_total += 1

        for k in TOP_KS:
            if hit_by_k[k]:
                per_split[split]["hits"][k] += 1
                overall_hits[k] += 1

        result_record = {
            "split": split,
            "conv_id": turn["conv_id"],
            "turn_index": turn["turn_index"],
            "agent": turn["agent"],
            "query": query,
            "knowledge_source_labels": turn.get("knowledge_source_labels", []),
            "gold_doc_ids": gold_doc_ids,
            "retrieved_top10": [
                {
                    "rank": idx + 1,
                    "doc_id": item["doc_id"],
                    "entity": item["entity"],
                    "score": round(item["score"], 4),
                    "text": item["text"]
                }
                for idx, item in enumerate(hits)
            ],
            "hit@1": hit_by_k[1],
            "hit@3": hit_by_k[3],
            "hit@5": hit_by_k[5],
            "hit@10": hit_by_k[10],
        }
        all_results.append(result_record)

        if len(sample_examples) < 5:
            sample_examples.append({
                "split": split,
                "query": query,
                "gold_doc_ids": gold_doc_ids,
                "top5": [
                    {
                        "rank": idx + 1,
                        "doc_id": item["doc_id"],
                        "entity": item["entity"],
                        "score": round(item["score"], 4),
                        "text_preview": short_text(item["text"], 180),
                    }
                    for idx, item in enumerate(hits[:5])
                ],
                "hit@5": hit_by_k[5]
            })

    summary = {
        "num_turns": overall_total,
        "overall": {
            f"recall@{k}": round(overall_hits[k] / overall_total, 4) if overall_total > 0 else 0.0
            for k in TOP_KS
        },
        "per_split": {}
    }

    for split, stat in per_split.items():
        n = stat["num_turns"]
        summary["per_split"][split] = {
            "num_turns": n,
            **{
                f"recall@{k}": round(stat["hits"][k] / n, 4) if n > 0 else 0.0
                for k in TOP_KS
            }
        }

    return summary, sample_examples, all_results


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True, help="Path to your NLP Project folder")
    parser.add_argument(
        "--eval_splits",
        nargs="*",
        default=["valid_freq", "valid_rare"],
        help="Splits to evaluate. Default: valid_freq valid_rare"
    )
    args = parser.parse_args()

    repo = Path(args.repo).expanduser().resolve()

    wiki_docs_path = repo / "outputs" / "wiki_docs.jsonl"
    grounded_turns_path = repo / "outputs" / "fs_grounded_turns.jsonl"

    if not wiki_docs_path.exists():
        raise FileNotFoundError(f"Missing file: {wiki_docs_path}")
    if not grounded_turns_path.exists():
        raise FileNotFoundError(f"Missing file: {grounded_turns_path}")

    wiki_docs = load_jsonl(wiki_docs_path)
    grounded_turns = load_jsonl(grounded_turns_path)

    retriever = BM25Retriever(wiki_docs)

    selected_turns = [
        t for t in grounded_turns
        if t.get("split") in args.eval_splits and len(t.get("gold_doc_ids", [])) > 0
    ]

    all_fs_with_gold = selected_turns

    clean_wiki_only = [
        t for t in selected_turns
        if not has_prefix(t.get("knowledge_source_labels", []), "AS")
        and not t.get("uses_personal_knowledge", False)
    ]

    all_summary, all_examples, _ = compute_metrics(all_fs_with_gold, retriever)
    clean_summary, clean_examples, clean_results = compute_metrics(clean_wiki_only, retriever)

    output_summary = {
        "num_docs": len(wiki_docs),
        "eval_splits": args.eval_splits,
        "all_fs_with_gold": all_summary,
        "clean_wiki_only": clean_summary,
    }

    outputs_dir = repo / "outputs"
    save_json(outputs_dir / "checkpoint_03_bm25_eval.json", output_summary)
    save_json(outputs_dir / "checkpoint_03_bm25_examples.json", {
        "all_fs_with_gold_examples": all_examples,
        "clean_wiki_only_examples": clean_examples,
    })
    save_jsonl(outputs_dir / "checkpoint_03_bm25_clean_wiki_top10.jsonl", clean_results)

    print("\n" + "=" * 100)
    print("CHECKPOINT 3 RESULTS")
    print("=" * 100)
    print(f"Number of wiki docs indexed : {len(wiki_docs)}")
    print(f"Evaluation splits           : {args.eval_splits}")
    print(f"All FS turns with gold docs : {len(all_fs_with_gold)}")
    print(f"Clean wiki-only turns       : {len(clean_wiki_only)}")

    print("\nALL_FS_WITH_GOLD")
    print(json.dumps(all_summary, indent=2, ensure_ascii=False))

    print("\nCLEAN_WIKI_ONLY")
    print(json.dumps(clean_summary, indent=2, ensure_ascii=False))

    print("\nSample clean_wiki_only examples:")
    for idx, ex in enumerate(clean_examples[:3], start=1):
        print("\n" + "-" * 100)
        print(f"Example {idx}")
        print(f"Split       : {ex['split']}")
        print(f"Hit@5       : {ex['hit@5']}")
        print(f"Query       : {short_text(ex['query'], 220)}")
        print(f"Gold docs   : {ex['gold_doc_ids']}")
        print("Top 5 hits:")
        for item in ex["top5"]:
            print(
                f"  {item['rank']:>2}. {item['doc_id']} | entity={item['entity']} "
                f"| score={item['score']}\n"
                f"      {item['text_preview']}"
            )

    print("\nSaved files:")
    print(f"  {outputs_dir / 'checkpoint_03_bm25_eval.json'}")
    print(f"  {outputs_dir / 'checkpoint_03_bm25_examples.json'}")
    print(f"  {outputs_dir / 'checkpoint_03_bm25_clean_wiki_top10.jsonl'}")

    print("\nDONE. Paste the terminal output here.")


if __name__ == "__main__":
    main()