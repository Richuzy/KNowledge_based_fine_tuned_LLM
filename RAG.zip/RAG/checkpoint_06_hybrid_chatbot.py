from __future__ import annotations

import argparse
import copy
import json
import re
from pathlib import Path
from typing import Any

import chromadb
import torch
from sentence_transformers import SentenceTransformer

from checkpoint_04_rag_generate import load_jsonl, BM25Retriever, load_model_and_tokenizer


TOKEN_PATTERN = re.compile(r"[a-z0-9]+")
STOPWORDS = {
    "a", "an", "the", "is", "are", "was", "were", "am", "be", "been", "being",
    "do", "does", "did", "what", "who", "when", "where", "why", "how",
    "i", "you", "he", "she", "it", "we", "they", "me", "him", "her", "them",
    "my", "your", "his", "their", "our", "this", "that", "these", "those",
    "to", "of", "in", "on", "for", "with", "about", "and", "or", "but",
    "at", "by", "from", "as", "if", "then", "than", "so", "because",
    "can", "could", "would", "should", "will", "just", "really", "very",
    "have", "has", "had", "there", "here", "into", "out", "up", "down"
}
REFERENTIAL_TOKENS = {
    "it", "its", "he", "him", "his", "she", "her", "hers", "they", "them", "their",
    "this", "that", "these", "those"
}


def tokenize(text: str) -> list[str]:
    return TOKEN_PATTERN.findall(text.lower()) if text else []


def normalize_token(tok: str) -> str:
    if tok.endswith("ies") and len(tok) > 4:
        return tok[:-3] + "y"
    if tok.endswith("s") and len(tok) > 3:
        return tok[:-1]
    return tok


def content_tokens(text: str) -> list[str]:
    toks = [normalize_token(t) for t in tokenize(text)]
    return [t for t in toks if t not in STOPWORDS and len(t) > 1]


def short_text(text: Any, limit: int = 220) -> str:
    if text is None:
        return "None"
    if not isinstance(text, str):
        text = json.dumps(text, ensure_ascii=False)
    text = text.replace("\n", " ").strip()
    return text if len(text) <= limit else text[:limit] + " ..."


def append_jsonl(path: Path, record: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


def history_to_text(chat_history: list[dict[str, str]], max_turns: int = 4) -> str:
    recent = chat_history[-max_turns:]
    lines = []
    for turn in recent:
        lines.append(f"{turn['role'].capitalize()}: {turn['content']}")
    return "\n".join(lines)


def last_user_turn(chat_history: list[dict[str, str]]) -> str:
    for turn in reversed(chat_history):
        if turn["role"] == "user":
            return turn["content"]
    return ""


def should_use_history_for_retrieval(query: str) -> bool:
    toks = tokenize(query)
    content = content_tokens(query)

    if not query.strip():
        return False

    lowered = query.strip().lower()
    if lowered.startswith("what about ") or lowered.startswith("and what about "):
        return True

    if any(t in REFERENTIAL_TOKENS for t in toks):
        return True

    if len(content) == 0:
        return True

    return False


def build_retrieval_query(query: str, chat_history: list[dict[str, str]]) -> str:
    if should_use_history_for_retrieval(query):
        prev_user = last_user_turn(chat_history)
        if prev_user:
            return f"{prev_user}\n{query}"
    return query


def get_or_create_collection(client, name: str):
    try:
        return client.get_or_create_collection(
            name=name,
            configuration={"hnsw": {"space": "cosine"}},
        )
    except TypeError:
        return client.get_or_create_collection(
            name=name,
            metadata={"hnsw:space": "cosine"},
        )


def chroma_search(collection, encoder, query: str, top_k: int = 5) -> list[dict[str, Any]]:
    emb = encoder.encode([query], normalize_embeddings=True).tolist()
    result = collection.query(
        query_embeddings=emb,
        n_results=top_k,
        include=["documents", "metadatas", "distances"],
    )

    ids = result.get("ids", [[]])[0]
    docs = result.get("documents", [[]])[0]
    metas = result.get("metadatas", [[]])[0]
    distances = result.get("distances", [[]])[0]

    hits = []
    for doc_id, doc_text, meta, dist in zip(ids, docs, metas, distances):
        hits.append({
            "doc_id": doc_id,
            "entity": (meta or {}).get("entity"),
            "text": doc_text,
            "dense_distance": float(dist) if dist is not None else None,
        })
    return hits


def rrf_merge(bm25_hits: list[dict[str, Any]], dense_hits: list[dict[str, Any]], k: int = 60) -> list[dict[str, Any]]:
    merged: dict[str, dict[str, Any]] = {}

    for rank, item in enumerate(bm25_hits, start=1):
        doc_id = item["doc_id"]
        merged.setdefault(doc_id, {
            "doc_id": doc_id,
            "entity": item.get("entity"),
            "text": item.get("text", ""),
            "bm25_score": None,
            "dense_distance": None,
            "bm25_rank": None,
            "dense_rank": None,
            "rrf_score": 0.0,
        })
        merged[doc_id]["bm25_score"] = float(item.get("score", 0.0))
        merged[doc_id]["bm25_rank"] = rank
        merged[doc_id]["rrf_score"] += 1.0 / (k + rank)

    for rank, item in enumerate(dense_hits, start=1):
        doc_id = item["doc_id"]
        merged.setdefault(doc_id, {
            "doc_id": doc_id,
            "entity": item.get("entity"),
            "text": item.get("text", ""),
            "bm25_score": None,
            "dense_distance": None,
            "bm25_rank": None,
            "dense_rank": None,
            "rrf_score": 0.0,
        })
        merged[doc_id]["entity"] = merged[doc_id]["entity"] or item.get("entity")
        merged[doc_id]["text"] = merged[doc_id]["text"] or item.get("text", "")
        merged[doc_id]["dense_distance"] = item.get("dense_distance")
        merged[doc_id]["dense_rank"] = rank
        merged[doc_id]["rrf_score"] += 1.0 / (k + rank)

    out = list(merged.values())
    out.sort(key=lambda x: x["rrf_score"], reverse=True)
    return out


def overlap_count(query: str, doc_text: str, entity: str | None) -> int:
    q = set(content_tokens(query))
    d = set(content_tokens(f"{entity or ''} {doc_text or ''}"))
    return len(q & d)


def has_enough_evidence(query: str, top_hits: list[dict[str, Any]], dense_distance_threshold: float = 0.85) -> tuple[bool, str]:
    if not top_hits:
        return False, "No retrieved docs."

    top = top_hits[0]
    overlap = overlap_count(query, top.get("text", ""), top.get("entity"))
    dense_distance = top.get("dense_distance")

    if overlap > 0:
        return True, f"Token overlap={overlap}"

    if dense_distance is not None and dense_distance <= dense_distance_threshold:
        return True, f"Dense distance={dense_distance:.4f}"

    return False, f"Weak match: overlap=0, dense_distance={dense_distance}"


def build_messages(query: str, history: str, retrieved_docs: list[dict[str, Any]]) -> list[dict[str, str]]:
    evidence_blocks = []
    for i, doc in enumerate(retrieved_docs, start=1):
        evidence_blocks.append(
            f"[{i}] Entity: {doc.get('entity')}\n"
            f"Document ID: {doc.get('doc_id')}\n"
            f"Text: {doc.get('text')}"
        )

    evidence_text = "\n\n".join(evidence_blocks) if evidence_blocks else "(no evidence)"
    history_text = history.strip() if history.strip() else "(none)"

    system_prompt = (
        "You are a knowledge-grounded explainer chatbot. "
        "Use only the retrieved evidence. "
        "Do not invent facts. "
        "Do not claim personal opinions, preferences, habits, or experiences. "
        "If the user asks about what you like, enjoy, think, or watch, say that you do not have personal opinions or experiences, "
        "then answer factually only from the evidence if possible. "
        "If the evidence is weak, unrelated, or insufficient, say that you do not have enough grounded evidence."
    )

    user_prompt = (
        f"Conversation history:\n{history_text}\n\n"
        f"Retrieved evidence:\n{evidence_text}\n\n"
        f"User question:\n{query}\n\n"
        f"Requirements:\n"
        f"- Answer in 2 to 4 sentences.\n"
        f"- Use only the evidence above.\n"
        f"- Never pretend to have personal preferences.\n"
        f"- End with: Sources: [1], [2]\n"
        f"  Only include source numbers that were actually useful.\n"
    )

    return [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]


def format_prompt(tokenizer, messages: list[dict[str, str]]) -> str:
    if hasattr(tokenizer, "apply_chat_template"):
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
        )

    parts = []
    for msg in messages:
        parts.append(f"{msg['role'].upper()}:\n{msg['content']}\n")
    parts.append("ASSISTANT:\n")
    return "\n".join(parts)


def generate_answer(tokenizer, model, messages: list[dict[str, str]], max_new_tokens: int = 90) -> str:
    prompt = format_prompt(tokenizer, messages)
    batch = tokenizer(prompt, return_tensors="pt")
    model_device = next(model.parameters()).device
    batch = {k: v.to(model_device) for k, v in batch.items()}

    gen_cfg = copy.deepcopy(model.generation_config)
    gen_cfg.do_sample = False

    for attr in ("temperature", "top_p", "top_k"):
        if hasattr(gen_cfg, attr):
            try:
                setattr(gen_cfg, attr, None)
            except Exception:
                pass

    with torch.no_grad():
        output = model.generate(
            **batch,
            generation_config=gen_cfg,
            max_new_tokens=max_new_tokens,
            repetition_penalty=1.05,
            use_cache=True,
            pad_token_id=tokenizer.eos_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )

    new_tokens = output[0][batch["input_ids"].shape[1]:]
    return tokenizer.decode(new_tokens, skip_special_tokens=True).strip()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True, help="Path to your NLP Project folder")
    parser.add_argument("--model_id", default="Qwen/Qwen2.5-1.5B-Instruct")
    parser.add_argument("--embed_model", default="sentence-transformers/all-MiniLM-L6-v2")
    parser.add_argument("--collection_name", default="topical_chat_wiki")
    parser.add_argument("--bm25_k", type=int, default=5)
    parser.add_argument("--dense_k", type=int, default=5)
    parser.add_argument("--final_k", type=int, default=3)
    parser.add_argument("--max_new_tokens", type=int, default=90)
    parser.add_argument("--max_history_turns", type=int, default=4)
    parser.add_argument("--embed_device", default="cpu")
    parser.add_argument("--dense_distance_threshold", type=float, default=0.85)
    args = parser.parse_args()

    repo = Path(args.repo).expanduser().resolve()

    wiki_docs_path = repo / "outputs" / "wiki_docs.jsonl"
    chroma_dir = repo / "vectorstores" / "chroma_wiki"

    if not wiki_docs_path.exists():
        raise FileNotFoundError(f"Missing file: {wiki_docs_path}")
    if not chroma_dir.exists():
        raise FileNotFoundError(f"Missing Chroma DB dir: {chroma_dir}")

    print("\nLoading wiki docs for BM25...")
    wiki_docs = load_jsonl(wiki_docs_path)
    bm25 = BM25Retriever(wiki_docs)
    print(f"Indexed docs: {len(wiki_docs)}")

    print("Loading Chroma collection...")
    client = chromadb.PersistentClient(path=str(chroma_dir))
    collection = get_or_create_collection(client, args.collection_name)
    print(f"Chroma rows: {collection.count()}")

    print(f"Loading embedding model on {args.embed_device}...")
    encoder = SentenceTransformer(args.embed_model, device=args.embed_device)

    print("Loading generator model once...")
    tokenizer, model = load_model_and_tokenizer(args.model_id)
    print("Generator loaded.")

    print("\n" + "=" * 90)
    print("HYBRID RAG CHATBOT")
    print(f"Generator: {args.model_id}")
    print(f"Embeddings: {args.embed_model}")
    print("Type 'exit' or 'quit' to stop.")
    print("=" * 90)

    chat_history: list[dict[str, str]] = []
    session_path = repo / "outputs" / "checkpoint_06_hybrid_chat_session.jsonl"

    while True:
        query = input("\nYou: ").strip()
        if not query:
            continue
        if query.lower() in {"exit", "quit"}:
            print("Exiting chat.")
            break

        history_text = history_to_text(chat_history, max_turns=args.max_history_turns)
        retrieval_query = build_retrieval_query(query, chat_history)

        bm25_hits = bm25.search(retrieval_query, top_k=args.bm25_k)
        dense_hits = chroma_search(collection, encoder, retrieval_query, top_k=args.dense_k)
        merged_hits = rrf_merge(bm25_hits, dense_hits)
        top_hits = merged_hits[:args.final_k]

        print("\nRetrieval query used:")
        print(retrieval_query)

        print("\nHybrid top docs:")
        for i, doc in enumerate(top_hits, start=1):
            print(
                f"  [{i}] {doc['doc_id']} | entity={doc.get('entity')} "
                f"| rrf={doc.get('rrf_score', 0):.4f} "
                f"| bm25={doc.get('bm25_score')} "
                f"| dense_dist={doc.get('dense_distance')}"
            )
            print(f"      {short_text(doc.get('text', ''), 170)}")

        good, reason = has_enough_evidence(
            query=query,
            top_hits=top_hits,
            dense_distance_threshold=args.dense_distance_threshold,
        )

        if not good:
            answer = "I do not have enough grounded evidence to answer that confidently."
            print(f"\nEvidence gate: BLOCKED ({reason})")
        else:
            print(f"\nEvidence gate: PASS ({reason})")
            messages = build_messages(query, history_text, top_hits)
            answer = generate_answer(
                tokenizer=tokenizer,
                model=model,
                messages=messages,
                max_new_tokens=args.max_new_tokens,
            )

        print(f"\nBot: {answer}")

        chat_history.append({"role": "user", "content": query})
        chat_history.append({"role": "assistant", "content": answer})

        append_jsonl(session_path, {
            "query": query,
            "history_used": history_text,
            "retrieval_query": retrieval_query,
            "top_hits": top_hits,
            "gate_reason": reason,
            "answer": answer,
        })

    print(f"\nChat saved to:\n{session_path}")


if __name__ == "__main__":
    main()